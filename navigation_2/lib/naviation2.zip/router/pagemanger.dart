import 'dart:async';

import 'package:flutter/material.dart';

class Pagemanger extends ChangeNotifier{
  late Completer<String> _completer;

  Future<String> waitforresult() async{
    _completer = Completer<String>();
    return _completer.future;
  }

  void returndata(String value){
    return _completer.complete(value);
  }
}