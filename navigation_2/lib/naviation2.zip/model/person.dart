class Person {
  final int id;
  final String nama;
  final String keahlian;
  const Person(this.id,this.nama, this.keahlian);
}

List<Person> personlis() => [
  Person(1,"bamabang", "dsfjlksdjflksjfdklsdjfksjdfksjdfks"),
  Person(2,"nur", "dsfjlksdjflvbnb0vn890bvnksjfdklsdjfksjdfksjdfks"),
  Person(3,"cahya", "gfjhlgfjlfkj"),
  Person(4,"babi", "pppppppppsdfnsdnfdsm"),
  Person(5,"bagus", "dsfjlksdjflksjfdklsdjfksjdfksjdfks"),
  Person(6,"haryanti", "dfgpdfogpfdg[podfgpfd]"),
  Person(7,"zuhda", "wemr.,wemr,.wme,.r"),
  Person(8,"zidan", "oicvubiocvuboi"),
];